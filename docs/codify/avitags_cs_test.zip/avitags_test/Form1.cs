using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using abcAVI; // abcAVI.dll namespace

namespace avitags_test
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		#region controls
		private System.Windows.Forms.ListView lvInfo;
		private System.Windows.Forms.Button btLoad;
		private System.Windows.Forms.ColumnHeader columnHeader1;
		private System.Windows.Forms.ColumnHeader columnHeader2;
		private System.Windows.Forms.OpenFileDialog openFileDialog;
		private System.Windows.Forms.Button btSave;
		private System.Windows.Forms.TextBox txtINAM;
		private System.Windows.Forms.Label label1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		#endregion

		public Form1()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lvInfo = new System.Windows.Forms.ListView();
			this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
			this.btLoad = new System.Windows.Forms.Button();
			this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
			this.btSave = new System.Windows.Forms.Button();
			this.txtINAM = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// lvInfo
			// 
			this.lvInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.lvInfo.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																											this.columnHeader1,
																											this.columnHeader2});
			this.lvInfo.Location = new System.Drawing.Point(16, 56);
			this.lvInfo.Name = "lvInfo";
			this.lvInfo.Size = new System.Drawing.Size(508, 280);
			this.lvInfo.TabIndex = 0;
			this.lvInfo.View = System.Windows.Forms.View.Details;
			// 
			// columnHeader1
			// 
			this.columnHeader1.Text = "Value";
			this.columnHeader1.Width = 226;
			// 
			// columnHeader2
			// 
			this.columnHeader2.Text = "Name";
			this.columnHeader2.Width = 240;
			// 
			// btLoad
			// 
			this.btLoad.Location = new System.Drawing.Point(16, 16);
			this.btLoad.Name = "btLoad";
			this.btLoad.Size = new System.Drawing.Size(56, 24);
			this.btLoad.TabIndex = 1;
			this.btLoad.Text = "Load";
			this.btLoad.Click += new System.EventHandler(this.btLoad_Click);
			// 
			// btSave
			// 
			this.btSave.Location = new System.Drawing.Point(88, 16);
			this.btSave.Name = "btSave";
			this.btSave.Size = new System.Drawing.Size(56, 24);
			this.btSave.TabIndex = 2;
			this.btSave.Text = "Save";
			this.btSave.Click += new System.EventHandler(this.btSave_Click);
			// 
			// txtINAM
			// 
			this.txtINAM.Location = new System.Drawing.Point(280, 16);
			this.txtINAM.Name = "txtINAM";
			this.txtINAM.Size = new System.Drawing.Size(216, 20);
			this.txtINAM.TabIndex = 3;
			this.txtINAM.Text = "";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(232, 16);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(48, 16);
			this.label1.TabIndex = 4;
			this.label1.Text = "INAM:";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(544, 373);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.txtINAM);
			this.Controls.Add(this.btSave);
			this.Controls.Add(this.btLoad);
			this.Controls.Add(this.lvInfo);
			this.Name = "Form1";
			this.Text = "abcAVI.dll - test";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}


	////////////////////////////////////////////////////////////////////
	/// abcAVI.dll C# sample

		/// <summary>
		/// avi main object with read, write methods
		/// </summary>
		private ExtendedAVITagsClass avi = null;

		/// <summary>
		/// avi info data
		/// </summary>
		object avi_info = null;	 

		/// <summary>
		/// loaded avi file name
		/// </summary>
		string file_name = "";

		private void btLoad_Click(object sender, System.EventArgs e)
		{
			int r; // read result
			string s = "";
			ListViewItem itm = null;
			int i;

			lvInfo.Items.Clear();

			// browse avi file
			if( openFileDialog.ShowDialog() == DialogResult.OK ) 
			{
				file_name = openFileDialog.FileName;
			} 
			else 
			{
				return;
			}

			
			try 
			{
				// create abcAVI object
				avi = new ExtendedAVITagsClass();

				// read avi tags and technical info
				r = avi.ReadAVITags( file_name, (CParse_Mode.PM_Ignore_Errors | CParse_Mode.PM_Tech_Info), 1, out avi_info);

				// read result in the caption
				this.Text = (string)avi.ErrorCodeToStr(r); 
				if( r != (int)CParse_Errors.PE_Parse_Ok ) return;

				// put INAM tag in the edit box
				txtINAM.Text = (string)avi.GetInfo(avi_info, CInfo_Type_ID.IDI_INFO_Tags, (int)abcAVI.CTags_ID.IDT_INAM );

				// put all tags in the listview
				lvInfo.BeginUpdate();

				// tags
				for(i=0; i<(int)CMax.IDT_max; i++ ) 
				{
					s = (string)avi.GetInfo(avi_info, CInfo_Type_ID.IDI_INFO_Tags, i);
					if( s != "" ) 
					{
						itm = new ListViewItem(s);
						itm.SubItems.Add( ((abcAVI.CTags_ID)i).ToString() );
						itm.BackColor = Color.Aqua;
						lvInfo.Items.Add(itm);
					}
				}

				// video info
				for(i=0; i<(int)CMax.IDV_max; i++) 
				{
					s = (string)avi.GetInfo(avi_info, CInfo_Type_ID.IDI_Video_Stream, i);
					if( s != "" ) 
					{
						itm = new ListViewItem(s);
						itm.SubItems.Add( ((abcAVI.CVideo_ID)i).ToString() );
						itm.BackColor = Color.Aquamarine;
						lvInfo.Items.Add(itm);
					}
				}

				// audio info (stream 1)
				for(i=0; i<(int)CMax.IDA_max; i++) 
				{
					s = (string)avi.GetInfo(avi_info, CInfo_Type_ID.IDI_Audio_Stream, i);
					if( s != "" ) 
					{
						itm = new ListViewItem(s);
						itm.SubItems.Add( ((abcAVI.CAudio_ID)i).ToString() );
						itm.BackColor = Color.Azure;
						lvInfo.Items.Add(itm);
					}
				}

				// audio info (stream 2)
				for(i=0; i<(int)CMax.IDA_max; i++) 
				{
					s = (string)avi.GetInfo(avi_info, CInfo_Type_ID.IDI_Audio_Stream2, i);
					if( s != "" ) 
					{
						itm = new ListViewItem(s);
						itm.SubItems.Add( ((abcAVI.CAudio_ID)i).ToString() );
						itm.BackColor = Color.Bisque;
						lvInfo.Items.Add(itm);
					}
				}

				// audio info (stream 3)
				for(i=0; i<(int)CMax.IDA_max; i++) 
				{
					s = (string)avi.GetInfo(avi_info, CInfo_Type_ID.IDI_Audio_Stream3, i);
					if( s != "" ) 
					{
						itm = new ListViewItem(s);
						itm.SubItems.Add( ((abcAVI.CAudio_ID)i).ToString() );
						itm.BackColor = Color.Coral;
						lvInfo.Items.Add(itm);
					}
				}

				// other tags
				for(i=0; i<(int)CMax.IDO_max; i++) 
				{
					s = (string)avi.GetInfo(avi_info, CInfo_Type_ID.IDI_Other_Tags, i);
					if( s != null && s != "" ) 
					{
						itm = new ListViewItem(s);
						itm.SubItems.Add( ((abcAVI.COther_Tags_ID)i).ToString() );
						itm.BackColor = Color.Beige;
						lvInfo.Items.Add(itm);
					}
				}

				lvInfo.EndUpdate();
			} 
			catch(Exception ex) 
			{
				// show error message
				MessageBox.Show(ex.Message);
			}

		}


		private void btSave_Click(object sender, System.EventArgs e)
		{
			if( avi == null ) return;
	
			try 
			{
				int r = avi.SetInfo(ref avi_info, CInfo_Type_ID.IDI_INFO_Tags, (int)abcAVI.CTags_ID.IDT_INAM, txtINAM.Text );
				this.Text = (string)avi.ErrorCodeToStr(r); 
				if( r != (int)CParse_Errors.PE_Parse_Ok ) return;
				r = avi.WriteAVITags(file_name, avi_info);
				this.Text = (string)avi.ErrorCodeToStr(r); 
			}
			catch(Exception ex) 
			{
				// show error message
				MessageBox.Show(ex.Message);
			}
		}
	}
}
