using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyVersion("0.1.1")]
[assembly: AssemblyTitle("themonospot-plugin-avi")]
[assembly: AssemblyDescription("themonospot-base plugin to manage Avi files")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Armando Basile")]
[assembly: AssemblyProduct("themonospot-plugin-avi")]
[assembly: AssemblyCopyright("(C) 2009 Armando Basile")]
[assembly: AssemblyTrademark("None")]
[assembly: AssemblyDelaySign(false)]

//[assembly: AssemblyKeyFile("themonospot-plugin-avi.snk")]


