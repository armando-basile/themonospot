
using System;

namespace ThemonospotBase
{
	
	// declare eventhandler for event CancelScan
	public delegate void CancelScanEventHandler(object sender, EventArgs args);
	
}
