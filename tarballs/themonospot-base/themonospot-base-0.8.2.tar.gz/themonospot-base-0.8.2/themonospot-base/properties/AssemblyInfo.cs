using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyVersion("0.8.2")]
[assembly: AssemblyTitle("themonospot-base")]
[assembly: AssemblyDescription("MONO/.Net component to parse/editor video files")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Armando Basile")]
[assembly: AssemblyProduct("themonospot-base")]
[assembly: AssemblyCopyright("(C) 2003-2009 Armando Basile")]
[assembly: AssemblyTrademark("None")]
[assembly: AssemblyDelaySign(false)]

//[assembly: AssemblyKeyFile("themonospot-base.snk")]


