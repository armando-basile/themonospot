using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyVersion("0.1.1")]
[assembly: AssemblyTitle("themonospot-plugin-mkv")]
[assembly: AssemblyDescription("themonospot-base plugin to manage Matroska files")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Armando Basile")]
[assembly: AssemblyProduct("themonospot-plugin-mkv")]
[assembly: AssemblyCopyright("(C) 2009 Armando Basile")]
[assembly: AssemblyTrademark("None")]
[assembly: AssemblyDelaySign(false)]

//[assembly: AssemblyKeyFile("themonospot-plugin-mkv.snk")]


