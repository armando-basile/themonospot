using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyVersion("0.2.2")]
[assembly: AssemblyTitle("themonospot-gui-gtk")]
[assembly: AssemblyDescription("Gtk gui for themonospot-base")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Armando Basile")]
[assembly: AssemblyProduct("themonospot-gui-gtk")]
[assembly: AssemblyCopyright("2003-2010 Armando Basile")]
[assembly: AssemblyTrademark("None")]
[assembly: AssemblyDelaySign(false)]

[assembly: AssemblyKeyFile("")]


