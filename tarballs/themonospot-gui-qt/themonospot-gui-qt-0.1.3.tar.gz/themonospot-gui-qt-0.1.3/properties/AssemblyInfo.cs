using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyVersion("0.1.3")]
[assembly: AssemblyTitle("themonospot-gui-qt")]
[assembly: AssemblyDescription("Qt gui for themonospot-base")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Armando Basile")]
[assembly: AssemblyProduct("themonospot-gui-qt")]
[assembly: AssemblyCopyright("(C) 2008-2009 Armando Basile")]
[assembly: AssemblyTrademark("None")]
[assembly: AssemblyDelaySign(false)]

//[assembly: AssemblyKeyFile("themonospot-gui-qt.snk")]


